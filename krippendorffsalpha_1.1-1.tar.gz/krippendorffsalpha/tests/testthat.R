
library(testthat)
library(krippendorffsalpha)

test_check("krippendorffsalpha")
